# customreact-loader-ui

A simple customizable React loader UI component that works in both **Create React App** and **Vite** projects.

---

## 📦 Installation

```bash
npm install customreact-loader-ui


import React from "react";
import { Loader } from "customreact-loader-ui";

function App() {
  return (
    <div>
      <h1>Loading...</h1>
      <Loader size="60px" color="#ff6600" />
    </div>
  );
}

export default App;
