// src/index.js
import ConfirmDeleteModal from './ConfirmDeleteModal';
export default ConfirmDeleteModal;
