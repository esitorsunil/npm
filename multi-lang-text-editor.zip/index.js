import languageReducer, { setLanguage, translateText } from './languageSlice.js';

export { languageReducer, setLanguage, translateText };
