// src/App.jsx
import { useState } from 'react';
import MyQuillEditor from './components/MyQuillEditor';

function App() {
  const [content, setContent] = useState('<p>Start typing here...</p>');

  return (
    <div style={{ padding: '2rem' }}>
      <h2>📝 Advanced Custom Quill Toolbar</h2>
      <MyQuillEditor value={content} onChange={setContent} />
      <hr />
      <h3>Preview:</h3>
      <div
        dangerouslySetInnerHTML={{ __html: content }}
        style={{
          padding: '1rem',
          border: '1px solid #ccc',
          borderRadius: '8px',
          marginTop: '1rem',
        }}
      />
    </div>
  );
}

export default App;
