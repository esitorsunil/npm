import React from 'react'
// import Form from './Form';
import {Form} from 'react-unique-dynamic-form'


const MyForm2 = () => {
 const initialValues = {
    name: "",
    fathername: "",
    username: { value: "", optional: true },
    email: "",
    phone: "",
    gender: ["male", "female"],
   
    study: {
      degree: true,
      university: true,
      notifications: false,
    },
    phoneOptions: ["ha", "kdf"],
  };

  const onSubmit = (values) => {
    console.log("Submitted:", values);
  };

  return <Form initialValues={initialValues} onSubmit={onSubmit} />;
};
export default MyForm2